
Empty Recycle Bin [version 1.00]


 Empties the Windows Recycle Bin.


 Syntax: EmptyRecycleBin.exe [/Q]

 /Q suppresses the 'Are you sure?' prompt and the progress bar.

 /? or -? displays this syntax and always returns 1.
  A successful completion returns 0.


Copyright 2002 Marty List, Marty@OptimumX.com


=======================================================================

System Requirements: Windows XP; Windows 2000; Windows ME; Windows 98
		     Windows NT4 and Windows 95 require Active Desktop.


Revision History:

1.00 	08/28/2002
Initial release.
